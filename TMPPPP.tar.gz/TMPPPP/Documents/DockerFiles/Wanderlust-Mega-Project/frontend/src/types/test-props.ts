interface TestProps {
  testId?: string;
}

export type { TestProps };
