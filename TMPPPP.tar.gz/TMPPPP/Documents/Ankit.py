print(2+4)
