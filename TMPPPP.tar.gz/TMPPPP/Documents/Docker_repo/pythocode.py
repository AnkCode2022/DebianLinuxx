import math

num=5

print(math.factorial(num))
