deostr="This is my first DOckerfile images practice i will write code to count word and letter and print that"

splt=deostr.split(" ")
print("Total i count -> ",deostr.count("i"))
print([i for i in splt if "i" in i])
