ank_user@debian:~/Documents/AWKK$ traceroute amazone.com
traceroute to amazone.com (99.83.179.101), 30 hops max, 60 byte packets
 1  _gateway (192.168.1.1)  1.262 ms  1.348 ms  2.645 ms
 2  * * *
awk '/amazone.com/{print $0}'  empl.log  this line will print all sentense jisme amazone keyword h


awk '{print NR $0}'  empl.log   ti print all line with line number


awk 'NR==3,NR==6 {print NR $0}'  empl.log this line will print all from line no3 to 6

awk 'NF==0 {print NR}' filename to get empty lines


awk '/amazone.com|netflix.com/{print NR $0}'  empl.log to search more than 1 word

awk 'BEGIN{INGORECASE=1} /amazone.com{print NR $0}'  empl.log to ignore uperlower case



awk -F, $NF>5000 '{print $0}' csvname here "," is delimenter


awk -F[,:] '{print $4}' filename  : in case of multiple delimenter, here this cmd will print "," k bad nad ":" k phle

awk '/amazone.com/ {count++} END {print count}' Code1.sh to count "amazone"

-----------
SED
----------





sed -n -e /'amazone.com/=' filename
