import os
import sys
import datetime
import logging

tag_clone_dir="/home/ank_user"
final_dir=f'{tag_clone_dir}/TagClone'

username=sys.argv[1]
passwd=sys.argv[2]





# function for converting normal username nad passwd into its ascii
def final_usrpaswd():
    global fuser
    global fpasswd
    fuser=""
    fpasswd=""
    asci_user_lst=['!','@','#','$','%','^','&','*']
    for i in username:
        if i in asci_user_lst:
            fuser+=str(ord(i))
        else:
            fuser+=i
    for j in passwd:
        if j in asci_user_lst:
            fpasswd+=str(ord(j))
        else:
            fpasswd+=j
    print("Final username:",fuser)
    print("FInal passwd :",fpasswd)
    print(tag_clone_dir)
    print(final_dir)


# function for git clone:

def gitclonefun():
    print("Git clone path is ",{tag_clone_dir})
    if os.path.exists(f'{final_dir}'):
        print("TagClone Already present , deleting the same!")
        cmd_delt=f'cd {tag_clone_dir};rm -rf TagClone'
        result_cdm_del=os.system(cmd_delt)
        if result_cdm_del!=0:
            print("Failure in deleting the TagClone")
            sys.exit(1)
        print("Existing TagClone dir has been deleted!!")
    cmd_gitclone=f'cd {tag_clone_dir}; mkdir TagClone; cd TagClone;git clone https://{fuser}:{fpasswd}@github.com/AnkCode2022/Docker_repo.git'
    result_git_clone=os.system(cmd_gitclone)
    if result_git_clone!=0:
        print("GitClone Failed !!")
        sys.exit(1)
    print("Git clone successful")

    cmd_checkout=f'cd {final_dir}/Docker_repo;git checkout DummyBranch; ls -lrt'
    result_cmd_checkout=os.system(cmd_checkout)

    if result_cmd_checkout!=0:
        print("checkout is failed")
    print("checkout is Successful")
    sys.exit(1)
    print(cmd_checkout)


final_usrpaswd()
gitclonefun()